# Dayflow HR Pro - Hackathon Edition

A modern, full-stack Human Resource Management System built for hackathons with React, TypeScript, Express.js, and SQLite.

## 🚀 Features

- **Employee Management** - Complete employee profiles and data management
- **Attendance Tracking** - Real-time check-in/check-out system
- **Leave Management** - Streamlined leave requests and approvals
- **Payroll System** - Transparent salary management
- **Role-Based Access** - Secure admin and employee dashboards
- **Analytics Dashboard** - Visual insights and metrics
- **Fully Responsive** - Works on desktop, tablet, and mobile

## 🛠️ Tech Stack

### Frontend
- **React 18** - UI library
- **TypeScript** - Type safety
- **Vite** - Fast build tool
- **Shadcn UI** - Component library
- **TailwindCSS** - Styling
- **React Router** - Navigation
- **TanStack Query** - Data fetching

### Backend
- **Express.js** - Web framework
- **SQLite** - Database (zero configuration)
- **JWT** - Authentication
- **bcryptjs** - Password hashing

## 📦 Quick Start

### Prerequisites
- Node.js 18+ and npm installed

### Installation & Running

#### 1. Install Frontend Dependencies
```bash
npm install
```

#### 2. Install Backend Dependencies
```bash
cd backend
npm install
cd ..
```

#### 3. Start Backend Server
```bash
# In a new terminal
cd backend
npm run dev
```
Backend will run on `http://localhost:3001`

#### 4. Start Frontend Development Server
```bash
# In another terminal (from root directory)
npm run dev
```
Frontend will run on `http://localhost:8080`

## 🎯 For Hackathon Judges

### What Makes This Special

1. **Full-Stack Implementation** - Complete frontend and backend integration
2. **Real Database** - Persistent data storage with SQLite
3. **Authentication** - Secure JWT-based auth system
4. **Role-Based Access Control** - Different views for admin and employees
5. **Modern UI/UX** - Beautiful, responsive design with smooth animations
6. **Production-Ready** - Clean code, proper error handling, and API design

### Quick Demo Flow

1. **Landing Page** - Visit `http://localhost:8080`
2. **Sign Up** - Create an admin account
3. **Dashboard** - Explore the admin dashboard with stats
4. **Attendance** - Test check-in/check-out functionality
5. **Leave Management** - Create and manage leave requests
6. **Employee Management** - Add and manage employees

### Test Accounts

Create these via the signup page or API:

**Admin:**
- Email: `admin@dayflow.com`
- Password: `admin123`
- Role: `admin`

**Employee:**
- Email: `employee@dayflow.com`
- Password: `employee123`
- Role: `employee`

## 📁 Project Structure

```
dayflow-hr-pro-main/
├── backend/              # Express.js API server
│   ├── server.js        # Main server file
│   ├── package.json     # Backend dependencies
│   ├── .env            # Environment variables
│   └── dayflow.db      # SQLite database (auto-created)
├── src/
│   ├── components/      # React components
│   ├── pages/          # Page components
│   ├── lib/            # Utilities and API client
│   └── App.tsx         # Main app component
├── package.json        # Frontend dependencies
└── README.md          # This file
```

## 🔌 API Endpoints

See `backend/README.md` for complete API documentation.

**Base URL:** `http://localhost:3001/api`

Key endpoints:
- `POST /auth/login` - User login
- `POST /auth/register` - User registration
- `GET /employees` - Get all employees
- `POST /attendance/checkin` - Check in
- `GET /leave` - Get leave requests
- `GET /stats/dashboard` - Dashboard stats

## 🎨 Features Implemented

### Frontend
- ✅ Responsive landing page
- ✅ Authentication (login/signup)
- ✅ Employee dashboard
- ✅ Admin dashboard
- ✅ Attendance tracking UI
- ✅ Leave management UI
- ✅ Payroll viewing
- ✅ Profile management

### Backend
- ✅ RESTful API
- ✅ JWT authentication
- ✅ User management
- ✅ Attendance CRUD
- ✅ Leave CRUD
- ✅ Payroll CRUD
- ✅ Dashboard statistics
- ✅ Role-based access control

## 🔧 Environment Variables

### Frontend (`.env`)
```env
VITE_API_URL=http://localhost:3001/api
```

### Backend (`backend/.env`)
```env
PORT=3001
JWT_SECRET=dayflow-hackathon-secret-key-2026
NODE_ENV=development
```

## 🚀 Deployment

### Frontend
```bash
npm run build
# Deploy the 'dist' folder to any static hosting (Vercel, Netlify, etc.)
```

### Backend
```bash
cd backend
npm start
# Deploy to any Node.js hosting (Heroku, Railway, Render, etc.)
```

## 📝 License

MIT - Built for Hackathon

## 👥 Contributing

This is a hackathon project. Feel free to fork and modify!

---

**Built with ❤️ for Hackathon 2026**

